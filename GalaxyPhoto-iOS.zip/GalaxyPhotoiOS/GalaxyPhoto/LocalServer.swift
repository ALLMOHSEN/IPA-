import Foundation
import Network

/// Serves the bundled site on http://localhost so the page runs in a secure context (required for the camera).
final class LocalServer {
    private var listener: NWListener?
    private(set) var isRunning = false
    private let allowed: Set<String> = ["html", "js", "css", "png", "woff2", "ttf"]

    func start(onReady: @escaping (UInt16) -> Void) {
        listener?.cancel()
        isRunning = false
        attempt(8767, onReady)
    }

    private func attempt(_ p: UInt16, _ onReady: @escaping (UInt16) -> Void) {
        guard p < 8800, let port = NWEndpoint.Port(rawValue: p) else { return }
        let params = NWParameters.tcp
        params.requiredInterfaceType = .loopback
        guard let l = try? NWListener(using: params, on: port) else { attempt(p + 1, onReady); return }
        l.newConnectionHandler = { [weak self] c in self?.handle(c) }
        l.stateUpdateHandler = { [weak self, weak l] state in
            switch state {
            case .ready:
                self?.isRunning = true
                onReady(p)
            case .failed:
                self?.isRunning = false
                l?.cancel()
                self?.attempt(p + 1, onReady)
            case .cancelled:
                self?.isRunning = false
            default:
                break
            }
        }
        listener = l
        l.start(queue: .global())
    }

    private func handle(_ c: NWConnection) {
        c.start(queue: .global())
        c.receive(minimumIncompleteLength: 1, maximumLength: 16384) { data, _, _, _ in
            guard let d = data, let text = String(data: d, encoding: .utf8) else { c.cancel(); return }
            let first = text.components(separatedBy: "\r\n").first ?? ""
            let parts = first.split(separator: " ")
            var path = parts.count > 1 ? String(parts[1]) : "/"
            if let q = path.firstIndex(of: "?") { path = String(path[..<q]) }
            if path == "/" { path = "/index.html" }
            let name = String(path.dropFirst())
            let ext = (name as NSString).pathExtension.lowercased()

            var status = "404 Not Found"
            var type = "text/plain; charset=utf-8"
            var body = Data("Not found".utf8)
            if !name.isEmpty, !name.contains(".."), self.allowed.contains(ext), let base = Bundle.main.resourceURL,
               let file = try? Data(contentsOf: base.appendingPathComponent(name)) {
                status = "200 OK"
                body = file
                switch ext {
                case "html": type = "text/html; charset=utf-8"
                case "js": type = "application/javascript"
                case "css": type = "text/css"
                case "png": type = "image/png"
                case "woff2": type = "font/woff2"
                default: type = "font/ttf"
                }
            }
            let head = "HTTP/1.1 \(status)\r\nContent-Type: \(type)\r\nContent-Length: \(body.count)\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n"
            var out = Data(head.utf8)
            out.append(body)
            c.send(content: out, completion: .contentProcessed { _ in c.cancel() })
        }
    }
}
