import UIKit
import WebKit

/// Full-screen photo booth: the same site as the Android app, with a native bridge for printing and the QR upload.
final class ViewController: UIViewController, WKScriptMessageHandler, WKUIDelegate, WKNavigationDelegate,
                            UIPrintInteractionControllerDelegate {
    private var webView: WKWebView!
    private let server = LocalServer()

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }

    /// Exposes the same `AndroidBridge` object the page already uses, so index.html is identical on both platforms.
    private static let shim = """
    window.AndroidBridge = {
      printCopies: function(u, n) { webkit.messageHandlers.bridge.postMessage({op: 'print', url: u, copies: n}); },
      printImage: function(u) { webkit.messageHandlers.bridge.postMessage({op: 'print', url: u, copies: 1}); },
      uploadPhoto: function(u, id) { webkit.messageHandlers.bridge.postMessage({op: 'upload', url: u, id: id}); },
      configurePrinter: function() { webkit.messageHandlers.bridge.postMessage({op: 'config'}); }
    };
    """

    override func loadView() {
        view = UIView()
        view.backgroundColor = UIColor(red: 0.96, green: 0.93, blue: 1.0, alpha: 1)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        let conf = WKWebViewConfiguration()
        conf.allowsInlineMediaPlayback = true
        conf.mediaTypesRequiringUserActionForPlayback = []
        let ucc = WKUserContentController()
        ucc.addUserScript(WKUserScript(source: Self.shim, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        ucc.add(self, name: "bridge")
        conf.userContentController = ucc

        webView = WKWebView(frame: view.bounds, configuration: conf)
        webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        webView.uiDelegate = self
        webView.navigationDelegate = self
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.scrollView.bounces = false
        webView.isOpaque = false
        webView.backgroundColor = view.backgroundColor
        view.addSubview(webView)

        UIApplication.shared.isIdleTimerDisabled = true
        NotificationCenter.default.addObserver(self, selector: #selector(becameActive),
                                               name: UIApplication.didBecomeActiveNotification, object: nil)
        startServer()
    }

    private func startServer() {
        server.start { [weak self] port in
            DispatchQueue.main.async {
                guard let self = self, let url = URL(string: "http://localhost:\(port)/index.html") else { return }
                self.webView.load(URLRequest(url: url))
            }
        }
    }

    @objc private func becameActive() {
        if !server.isRunning { startServer() }
    }

    // MARK: WebView delegates

    /// Camera access for our own page (the system asks the user once through NSCameraUsageDescription).
    func webView(_ webView: WKWebView, requestMediaCapturePermissionFor origin: WKSecurityOrigin,
                 initiatedByFrame frame: WKFrameInfo, type: WKMediaCaptureType,
                 decisionHandler: @escaping (WKPermissionDecision) -> Void) {
        decisionHandler(.grant)
    }

    /// Booth mode: never navigate away from the bundled page.
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        let url = navigationAction.request.url
        decisionHandler(url?.host == "localhost" || url?.scheme == "about" ? .allow : .cancel)
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        webView.reload()
    }

    // MARK: Bridge

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: Any], let op = body["op"] as? String else { return }
        switch op {
        case "print":
            printPhoto(dataUrl: body["url"] as? String ?? "", copies: (body["copies"] as? Int) ?? 1)
        case "upload":
            upload(dataUrl: body["url"] as? String ?? "", id: (body["id"] as? Int) ?? 0)
        case "config":
            pickPrinter()
        default:
            break
        }
    }

    private static func decode(_ dataUrl: String) -> Data? {
        guard let i = dataUrl.firstIndex(of: ",") else { return nil }
        return Data(base64Encoded: String(dataUrl[dataUrl.index(after: i)...]), options: .ignoreUnknownCharacters)
    }

    private var popoverRect: CGRect {
        CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
    }

    // MARK: Printing (AirPrint)

    /// With a saved printer (long-press the logo to choose it): prints silently. Otherwise shows the system print screen.
    private func printPhoto(dataUrl: String, copies: Int) {
        guard let data = Self.decode(dataUrl) else { return }
        let n = max(1, min(copies, 4))
        let pc = UIPrintInteractionController.shared
        let info = UIPrintInfo(dictionary: nil)
        info.outputType = .photo
        info.jobName = "Galaxy Photo"
        info.orientation = .portrait
        pc.printInfo = info
        pc.printingItems = Array(repeating: data, count: n)
        pc.delegate = self

        if let s = UserDefaults.standard.string(forKey: "printer_url"), let url = URL(string: s) {
            pc.print(to: UIPrinter(url: url)) { [weak self] _, completed, error in
                if !completed && error != nil {
                    DispatchQueue.main.async { self?.presentPrintScreen(pc) }
                }
            }
        } else {
            presentPrintScreen(pc)
        }
    }

    private func presentPrintScreen(_ pc: UIPrintInteractionController) {
        if UIDevice.current.userInterfaceIdiom == .pad {
            pc.present(from: popoverRect, in: view, animated: true, completionHandler: nil)
        } else {
            pc.present(animated: true, completionHandler: nil)
        }
    }

    /// 4x6 in = 288x432 pt (or the closest paper the printer offers, e.g. Postcard).
    func printInteractionController(_ printInteractionController: UIPrintInteractionController,
                                    choosePaper paperList: [UIPrintPaper]) -> UIPrintPaper {
        return UIPrintPaper.bestPaper(forPageSize: CGSize(width: 288, height: 432), withPapersFrom: paperList)
    }

    private func pickPrinter() {
        let saved = UserDefaults.standard.string(forKey: "printer_url")
            .flatMap { URL(string: $0) }.map { UIPrinter(url: $0) }
        let picker = UIPrinterPickerController(initiallySelectedPrinter: saved)
        let done: UIPrinterPickerController.CompletionHandler = { controller, selected, _ in
            if selected, let p = controller.selectedPrinter {
                UserDefaults.standard.set(p.url.absoluteString, forKey: "printer_url")
            }
        }
        if UIDevice.current.userInterfaceIdiom == .pad {
            picker.present(from: popoverRect, in: view, animated: true, completionHandler: done)
        } else {
            picker.present(animated: true, completionHandler: done)
        }
    }

    // MARK: QR upload (temporary one-time link; nothing is kept on the device)

    private func upload(dataUrl: String, id: Int) {
        guard let jpeg = Self.decode(dataUrl), let url = URL(string: "https://file.io/?expires=1h") else {
            report(id, "")
            return
        }
        let boundary = "----galaxy\(Int(Date().timeIntervalSince1970))"
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = 30
        req.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        req.setValue("application/json", forHTTPHeaderField: "Accept")

        var body = Data()
        body.append(Data(("--\(boundary)\r\nContent-Disposition: form-data; name=\"file\"; filename=\"galaxy-photo.jpg\"\r\n"
                          + "Content-Type: image/jpeg\r\n\r\n").utf8))
        body.append(jpeg)
        body.append(Data("\r\n--\(boundary)--\r\n".utf8))

        URLSession.shared.uploadTask(with: req, from: body) { [weak self] data, response, _ in
            var link = ""
            if let data = data, let http = response as? HTTPURLResponse, http.statusCode < 400,
               let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let l = obj["link"] as? String {
                link = l
            }
            self?.report(id, link)
        }.resume()
    }

    private func report(_ id: Int, _ link: String) {
        let literal = (try? JSONEncoder().encode(link)).flatMap { String(data: $0, encoding: .utf8) } ?? "\"\""
        DispatchQueue.main.async {
            self.webView.evaluateJavaScript("window.onShareResult&&window.onShareResult(\(id),\(literal))", completionHandler: nil)
        }
    }
}
